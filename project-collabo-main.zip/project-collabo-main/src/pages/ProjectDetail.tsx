import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Sidebar } from '@/components/Sidebar';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Send, Upload, Download } from 'lucide-react';

const ProjectDetail = () => {
  const { id } = useParams();
  const [message, setMessage] = useState('');

  // Mock data
  const project = {
    title: 'Mobile App Development',
    description: 'Building a cross-platform mobile application for student collaboration',
  };

  const tasks = [
    { id: 1, title: 'Design UI mockups', completed: true, assignee: 'John' },
    { id: 2, title: 'Implement authentication', completed: false, assignee: 'Sarah' },
    { id: 3, title: 'Setup database schema', completed: false, assignee: 'Mike' },
  ];

  const messages = [
    { id: 1, sender: 'John', content: 'Hey team, I uploaded the latest designs!', time: '10:30 AM' },
    { id: 2, sender: 'Sarah', content: 'Looks great! I\'ll start on the auth implementation.', time: '10:45 AM' },
  ];

  const files = [
    { id: 1, name: 'UI_Mockups.fig', size: '2.4 MB', uploadedBy: 'John', date: '2 days ago' },
    { id: 2, name: 'API_Documentation.pdf', size: '856 KB', uploadedBy: 'Sarah', date: '1 day ago' },
  ];

  return (
    <>
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <header className="h-14 flex items-center border-b px-4 gap-2">
          <SidebarTrigger />
          <h2 className="text-lg font-semibold">{project.title}</h2>
          <div className="flex-1" />
          <Button variant="outline" size="sm">
            <Plus className="w-4 h-4 mr-2" />
            Invite Member
          </Button>
        </header>
        
        <main className="flex-1 p-6 bg-background overflow-y-auto">
          <Tabs defaultValue="tasks" className="space-y-4">
            <TabsList>
              <TabsTrigger value="tasks">Tasks</TabsTrigger>
              <TabsTrigger value="chat">Chat</TabsTrigger>
              <TabsTrigger value="files">Files</TabsTrigger>
            </TabsList>

            <TabsContent value="tasks" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Project Tasks</CardTitle>
                  <CardDescription>Manage and track your project tasks</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {tasks.map((task) => (
                    <div key={task.id} className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-muted/50 transition-smooth">
                      <Checkbox checked={task.completed} />
                      <div className="flex-1">
                        <p className={task.completed ? 'line-through text-muted-foreground' : ''}>
                          {task.title}
                        </p>
                        <p className="text-sm text-muted-foreground">Assigned to {task.assignee}</p>
                      </div>
                    </div>
                  ))}
                  <Button variant="outline" className="w-full mt-4">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Task
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="chat">
              <Card className="h-[600px] flex flex-col">
                <CardHeader>
                  <CardTitle>Team Chat</CardTitle>
                  <CardDescription>Communicate with your team members</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col p-0">
                  <ScrollArea className="flex-1 p-6">
                    <div className="space-y-4">
                      {messages.map((msg) => (
                        <div key={msg.id} className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-sm">{msg.sender}</span>
                            <span className="text-xs text-muted-foreground">{msg.time}</span>
                          </div>
                          <p className="text-sm bg-muted p-3 rounded-lg">{msg.content}</p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                  <div className="p-4 border-t border-border">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Type a message..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                      />
                      <Button size="icon">
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="files">
              <Card>
                <CardHeader>
                  <CardTitle>Project Files</CardTitle>
                  <CardDescription>Upload and manage project documents</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {files.map((file) => (
                    <div key={file.id} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50 transition-smooth">
                      <div>
                        <p className="font-medium">{file.name}</p>
                        <p className="text-sm text-muted-foreground">
                          {file.size} • Uploaded by {file.uploadedBy} • {file.date}
                        </p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Download className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" className="w-full mt-4">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload File
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </>
  );
};

export default ProjectDetail;
