import { Sidebar } from '@/components/Sidebar';
import { TopBar } from '@/components/TopBar';
import { ProjectCard } from '@/components/ProjectCard';
import { Button } from '@/components/ui/button';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { Plus } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

// Mock data - replace with actual API calls
const mockProjects = [
  {
    id: '1',
    title: 'Mobile App Development',
    description: 'Building a cross-platform mobile application for student collaboration',
    progress: 65,
    dueDate: 'Dec 30, 2025',
    members: 4,
    status: 'active' as const,
  },
  {
    id: '2',
    title: 'AI Research Project',
    description: 'Exploring machine learning applications in educational technology',
    progress: 40,
    dueDate: 'Jan 15, 2026',
    members: 3,
    status: 'active' as const,
  },
  {
    id: '3',
    title: 'Web Portfolio',
    description: 'Creating a professional portfolio website showcasing projects',
    progress: 100,
    dueDate: 'Nov 20, 2025',
    members: 1,
    status: 'completed' as const,
  },
];

const Dashboard = () => {
  const { user } = useAuth();

  return (
    <>
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <header className="h-14 flex items-center border-b px-4 gap-2">
          <SidebarTrigger />
          <div className="flex-1" />
          {user?.role === 'student' && (
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              New Project
            </Button>
          )}
        </header>
        
        <main className="flex-1 p-6 bg-background overflow-y-auto">
          <div className="mb-6">
            <h3 className="text-2xl font-bold mb-1">
              Welcome back, {user?.name}! 👋
            </h3>
            <p className="text-muted-foreground">
              Here's what's happening with your projects today.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockProjects.map((project) => (
              <ProjectCard key={project.id} {...project} />
            ))}
          </div>
        </main>
      </div>
    </>
  );
};

export default Dashboard;
