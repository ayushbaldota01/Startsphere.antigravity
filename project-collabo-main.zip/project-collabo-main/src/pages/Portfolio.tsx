import { Sidebar } from '@/components/Sidebar';
import { SidebarTrigger } from '@/components/ui/sidebar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import { ExternalLink, Award, Mail, Linkedin, Github, MapPin, Briefcase, GraduationCap, Code2, Star, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Portfolio = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Mock portfolio data - in production, this would come from API
  const portfolioData = {
    bio: "Passionate software engineering student with a focus on building scalable web applications and AI-driven solutions. Currently pursuing B.Tech in Computer Science with hands-on experience in full-stack development.",
    location: "San Francisco, CA",
    email: user?.email || "user@example.com",
    github: "github.com/johndoe",
    linkedin: "linkedin.com/in/johndoe",
    
    skills: [
      { category: "Frontend", items: ["React", "TypeScript", "Tailwind CSS", "Next.js"] },
      { category: "Backend", items: ["Node.js", "Python", "PostgreSQL", "MongoDB"] },
      { category: "Tools", items: ["Git", "Docker", "AWS", "Firebase"] },
      { category: "AI/ML", items: ["TensorFlow", "PyTorch", "scikit-learn"] },
    ],
    
    experience: [
      {
        id: 1,
        role: "Software Engineering Intern",
        company: "Tech Startup Inc.",
        period: "June 2024 - Aug 2024",
        description: "Developed and deployed microservices using Node.js and Docker, reducing API response time by 40%",
      },
      {
        id: 2,
        role: "Research Assistant",
        company: "University AI Lab",
        period: "Jan 2024 - Present",
        description: "Working on machine learning models for educational technology, published 2 research papers",
      },
    ],
    
    education: [
      {
        id: 1,
        degree: "B.Tech in Computer Science",
        institution: "Stanford University",
        period: "2022 - 2026",
        gpa: "3.8/4.0",
      },
    ],
    
    projects: [
      {
        id: 1,
        title: 'Mobile App Development',
        description: 'Cross-platform mobile application for student collaboration with real-time features',
        technologies: ['React Native', 'Firebase', 'Node.js'],
        status: 'completed',
        github: 'github.com/project1',
        demo: 'demo.com/project1',
      },
      {
        id: 2,
        title: 'AI Research Project',
        description: 'Machine learning application for educational technology improvement',
        technologies: ['Python', 'TensorFlow', 'Flask'],
        status: 'in-progress',
        github: 'github.com/project2',
      },
      {
        id: 3,
        title: 'E-commerce Platform',
        description: 'Full-stack e-commerce solution with payment integration and inventory management',
        technologies: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
        status: 'completed',
        github: 'github.com/project3',
        demo: 'demo.com/project3',
      },
    ],
  };

  return (
    <>
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <header className="h-14 flex items-center border-b px-4 gap-2">
          <SidebarTrigger />
          <Button variant="ghost" size="sm" onClick={() => navigate('/profile')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Profile
          </Button>
          <div className="flex-1" />
          <Button size="sm" variant="outline">
            <ExternalLink className="w-4 h-4 mr-2" />
            View Public Profile
          </Button>
        </header>
        
        <main className="flex-1 p-6 bg-background overflow-y-auto">
          <div className="max-w-5xl mx-auto space-y-8">
            {/* Header Card */}
            <Card className="bg-gradient-to-r from-primary/10 to-accent/10 border-primary/20">
              <CardHeader>
                <div className="flex items-start justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-4">
                    <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center text-3xl text-primary-foreground font-bold">
                      {user?.name?.charAt(0).toUpperCase() || 'U'}
                    </div>
                    <div>
                      <CardTitle className="text-3xl">{user?.name || 'John Doe'}</CardTitle>
                      <CardDescription className="text-base mt-1">
                        Software Engineering Student | Full-Stack Developer
                      </CardDescription>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          {portfolioData.location}
                        </span>
                        <span className="flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          {portfolioData.email}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex gap-3">
                  <Button variant="outline" size="sm">
                    <Github className="w-4 h-4 mr-2" />
                    GitHub
                  </Button>
                  <Button variant="outline" size="sm">
                    <Linkedin className="w-4 h-4 mr-2" />
                    LinkedIn
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* About Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  About Me
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {portfolioData.bio}
                </p>
              </CardContent>
            </Card>

            {/* Skills Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code2 className="w-5 h-5" />
                  Skills & Technologies
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {portfolioData.skills.map((skillGroup) => (
                  <div key={skillGroup.category}>
                    <h4 className="font-semibold mb-2">{skillGroup.category}</h4>
                    <div className="flex flex-wrap gap-2">
                      {skillGroup.items.map((skill) => (
                        <Badge key={skill} variant="secondary">{skill}</Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Experience Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="w-5 h-5" />
                  Experience
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {portfolioData.experience.map((exp, index) => (
                  <div key={exp.id}>
                    {index > 0 && <Separator className="my-4" />}
                    <div>
                      <div className="flex items-start justify-between flex-wrap gap-2">
                        <div>
                          <h4 className="font-semibold text-lg">{exp.role}</h4>
                          <p className="text-muted-foreground">{exp.company}</p>
                        </div>
                        <Badge variant="outline">{exp.period}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-2">
                        {exp.description}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Education Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <GraduationCap className="w-5 h-5" />
                  Education
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {portfolioData.education.map((edu) => (
                  <div key={edu.id}>
                    <div className="flex items-start justify-between flex-wrap gap-2">
                      <div>
                        <h4 className="font-semibold text-lg">{edu.degree}</h4>
                        <p className="text-muted-foreground">{edu.institution}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="outline">{edu.period}</Badge>
                        <p className="text-sm text-muted-foreground mt-1">GPA: {edu.gpa}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Projects Section */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Featured Projects
                  </CardTitle>
                  <Button variant="outline" size="sm">
                    Manage Projects
                  </Button>
                </div>
                <CardDescription>
                  Projects published from your workspace
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {portfolioData.projects.map((project) => (
                  <Card key={project.id} className="border-muted">
                    <CardHeader>
                      <div className="flex items-start justify-between flex-wrap gap-2">
                        <div className="flex-1">
                          <CardTitle className="text-lg">{project.title}</CardTitle>
                          <CardDescription className="mt-1">{project.description}</CardDescription>
                        </div>
                        <Badge variant={project.status === 'completed' ? 'default' : 'secondary'}>
                          {project.status === 'completed' ? 'Completed' : 'In Progress'}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex flex-wrap gap-2">
                          {project.technologies.map((tech) => (
                            <Badge key={tech} variant="outline">{tech}</Badge>
                          ))}
                        </div>
                        <div className="flex gap-2">
                          {project.github && (
                            <Button variant="outline" size="sm">
                              <Github className="w-4 h-4 mr-2" />
                              Code
                            </Button>
                          )}
                          {project.demo && (
                            <Button variant="outline" size="sm">
                              <ExternalLink className="w-4 h-4 mr-2" />
                              Live Demo
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </>
  );
};

export default Portfolio;
